module Unroller
  def Unroller.trace
    level = 0;
    indents = []
    s = ""
    for i in 0..40 do
      indents[i] = s + "\u251C "
      s += "| "
    end

    set_trace_func proc { |event, file, line, id, binding, classname| 
      if (event == "call" or event == "return") 
        if event == 'call' and file.match(/^\/Users\/Dopson\/work\/website/) and file != '/Users/Dopson/work/website/lib/patches/log4r.rb'
          printf "%s%s (%s) %s:%-2d\n", indents[level], id, classname, file, line
        end
        level += 1 if event == 'call'
        level -= 1 if event == 'return'
      end
    }
    yield
    set_trace_func nil
  end
end
